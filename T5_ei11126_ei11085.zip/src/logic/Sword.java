package logic;

import java.io.Serializable;

/**
 * Represents the sword.
 */
public class Sword extends GameElement implements Serializable {
	private static final long serialVersionUID = 1L;
}
